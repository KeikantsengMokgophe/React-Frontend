import React from 'react'
import Jumbotron from './Jumbotron';
import Products from './Products'
import GitHub from './GitHub';

function App() {
  return (
    <div>
      <GitHub />
    </div>
  )
}

export default App