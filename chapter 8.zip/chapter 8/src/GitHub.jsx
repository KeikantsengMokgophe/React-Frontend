import { useState } from 'react';
import axios from 'axios'; // npm install axios
// import ReactLoading from 'react-loading';
import { Container, Row, Col, Card, Spinner } from 'react-bootstrap'; // npm install react-bootstrap bootstrap

function GitHub() {
    const [data, setData] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    const getData = async (term) => {
        setIsLoading(true);
        setError(null);
        try {
            const res = await axios.get('https://api.github.com/search/users', {
                params: { q: term },
            });
            setData(res.data.items);
        } catch (err) {
            setData([]);
            setError(err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        // GitHub's search API returns 422 for an empty query
        if (!searchTerm.trim()) return;
        getData(searchTerm.trim());
    };

    return (
        <Container className="py-4">
            <form onSubmit={handleSubmit} className="mb-4">
                <input
                    type="text"
                    value={searchTerm}
                    onChange={(event) => setSearchTerm(event.target.value)}
                    placeholder="Search GitHub users"
                />
                <button type="submit" disabled={isLoading}>
                    Search
                </button>
            </form>

            <h3>GitHub Users Results</h3>

            {isLoading && <Spinner animation="border" role="status" />}

            {error && <div className="text-danger fw-bold">{error.message}</div>}

            <Row xs={1} md={2} lg={3} className="g-3">
                {data.map((user) => (
                    <Col key={user.id}>
                        <Card className="h-100">
                            <Row className="g-0 align-items-center">
                                <Col xs="auto" className="p-3">
                                    <a href={user.html_url}>
                                        <img
                                            width={64}
                                            height={64}
                                            src={user.avatar_url}
                                            alt={`${user.login} avatar`}
                                        />
                                    </a>
                                </Col>
                                <Col>
                                    <Card.Body>
                                        <Card.Title as="h5">Login: {user.login}</Card.Title>
                                        <Card.Text>Id: {user.id}</Card.Text>
                                    </Card.Body>
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                ))}
            </Row>
        </Container>
    );
}

export default GitHub;
