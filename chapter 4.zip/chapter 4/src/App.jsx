import React from 'react';
import Products from './Products';
import { Button } from 'react-bootstrap';
import Rating from './Rating';

function App() {
  const isValid = false;



  return (
    <div>
      <Products />
    </div>
  );
}
export default App;